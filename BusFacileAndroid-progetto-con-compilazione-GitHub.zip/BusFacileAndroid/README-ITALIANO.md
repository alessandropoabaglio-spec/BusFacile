# BUS FACILE – progetto Android

Questo è un progetto Android Studio che incorpora localmente la pagina web `index.html` in una vera app Android chiamata BUS FACILE. Richiede Android Studio per generare il file APK; questo archivio contiene il progetto sorgente, non un APK già compilato.

## Cosa include
- Pagina BUS FACILE inclusa nell'app, senza dover aprire Chrome.
- Richiesta dei permessi Android per la posizione GPS.
- Connessione Internet per cercare le fermate e aprire Google Maps.
- Icona e nome dell'app.

## Come generare l'APK su Windows
1. Installa Android Studio dal sito ufficiale Android Developers.
2. Estrai tutto lo ZIP in una cartella del PC.
3. In Android Studio scegli **Open** e seleziona la cartella `BusFacileAndroid`.
4. Attendi la sincronizzazione Gradle e installa gli SDK richiesti se Android Studio lo chiede.
5. Dal menu scegli **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Al termine, premi **locate** nella notifica oppure cerca il file in:
   `app/build/outputs/apk/debug/app-debug.apk`
7. Trasferisci `app-debug.apk` sul Samsung Galaxy A16 e aprilo per installarlo.

## Family Link
L'installazione di APK da fuori Play Store può essere limitata dalle impostazioni del dispositivo supervisionato. Se il telefono blocca l'installazione, fermati e controlla le impostazioni/autorizzazioni da genitore in Family Link; non disattivare protezioni di sicurezza senza averne verificato la necessità.

## Nota sui dati autobus
L'app contiene la versione corrente della pagina web. La ricerca automatica delle corse programmate STAV/Movibus non è ancora integrata completamente: la pagina può cercare fermate vicine e aprire Google Maps o i siti ufficiali, ma non deve essere considerata un motore di orari in tempo reale.
